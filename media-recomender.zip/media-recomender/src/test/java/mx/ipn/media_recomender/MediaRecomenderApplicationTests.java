package mx.ipn.media_recomender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaRecomenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
