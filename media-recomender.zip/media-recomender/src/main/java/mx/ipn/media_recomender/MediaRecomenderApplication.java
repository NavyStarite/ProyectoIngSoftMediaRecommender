package mx.ipn.media_recomender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediaRecomenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaRecomenderApplication.class, args);
	}

}
